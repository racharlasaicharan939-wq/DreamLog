# DreamLog: Sleep & Study Intelligence
Open `index.html` in Chrome/Edge (no install, no server). Login: **student@gmail.com / dreamlog123**.

## 60-second demo (matches the brief)
1. Sign in. Dashboard shows 21 seeded days, r = +0.77 "Strong positive".
2. Sleep Logger: 23:30 → 07:30 (8.0 h), 4★ (pre-set) → Save.
3. Study Tracker: Algorithms, 4.5 h, 5★ (pre-filled) → Save.
4. r updates to +0.78, the new point glows amber on the scatter, insights show the "7.5+ hours = X% higher focus" line.
5. Try Bedtime recommender, Exam planner, Export report.
Reset anytime with "Reset demo data" in the footer.
