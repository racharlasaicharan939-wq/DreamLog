// ==========================================
// DREAMLOG - SLEEP & STUDY TRACKER
// Frontend-only project using LocalStorage
// ==========================================

// LOGIN SYSTEM

const loginForm = document.getElementById("loginForm");
const loginScreen = document.getElementById("loginScreen");
const app = document.getElementById("app");
const loginError = document.getElementById("loginError");

// UPDATED LOGIN CREDENTIALS
const DEMO_EMAIL = "student@gmail.com";
const DEMO_PASSWORD = "dreamlog123";

function showDashboard() {
  loginScreen.style.display = "none";
  app.classList.remove("locked");

  setTimeout(() => {
    if (sleepChart) sleepChart.resize();
  }, 200);
}

loginForm.addEventListener("submit", function (event) {
  event.preventDefault();

  const email = document.getElementById("loginEmail").value.trim();
  const password = document.getElementById("loginPassword").value;

  if (email === DEMO_EMAIL && password === DEMO_PASSWORD) {
    sessionStorage.setItem("dreamlogLoggedIn", "true");
    loginError.textContent = "";
    showDashboard();
    renderDashboard();
    showToast("Welcome to DreamLog!");
  } else {
    loginError.textContent = "Incorrect email or password. Try the demo account.";
  }
});

// Keep the login active during this browser tab session
if (sessionStorage.getItem("dreamlogLoggedIn") === "true") {
  showDashboard();
}

// Show / hide password
document.getElementById("togglePassword").addEventListener("click", function () {
  const password = document.getElementById("loginPassword");

  if (password.type === "password") {
    password.type = "text";
    this.textContent = "HIDE";
  } else {
    password.type = "password";
    this.textContent = "SHOW";
  }
});

// Logout
document.getElementById("logoutBtn").addEventListener("click", function () {
  sessionStorage.removeItem("dreamlogLoggedIn");
  location.reload();
});


// ==========================================
// DATA & DEMO RECORDS
// ==========================================

function getDateString(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function createDemoData() {
  // 21 days ending yesterday. [bedtime, wake, sleepHrs, quality, studyHrs, focus]
  // Tuned so r = +0.77 now and about +0.78 after the demo entry (8.0 h, focus 5).
  const rows = [["02:00", "07:30", 5.5, 1, 3.5, 1], ["22:30", "07:00", 8.5, 3, 5.5, 3], ["00:00", "07:00", 7, 3, 6.5, 4], ["02:00", "07:00", 5, 1, 2, 1], ["22:30", "07:00", 8.5, 5, 7.0, 5], ["23:00", "07:00", 8, 4, 3.0, 2], ["02:00", "07:30", 5.5, 1, 4.0, 1], ["01:30", "07:00", 5.5, 1, 4.0, 1], ["00:00", "07:00", 7, 4, 3.5, 3], ["23:30", "07:00", 7.5, 2, 5.0, 2], ["22:00", "07:00", 9, 5, 7.0, 5], ["01:00", "07:00", 6, 1, 5.0, 2], ["02:00", "07:30", 5.5, 1, 3.0, 2], ["23:30", "07:00", 7.5, 3, 3.0, 2], ["01:30", "07:00", 5.5, 1, 5.0, 2], ["23:30", "07:00", 7.5, 4, 6.5, 4], ["02:00", "07:30", 5.5, 1, 3.5, 1], ["02:30", "07:30", 5, 1, 3.0, 1], ["00:00", "07:00", 7, 3, 2.5, 1], ["01:00", "07:00", 6, 2, 5.0, 2], ["00:30", "07:30", 7, 3, 5.0, 3]];
  const subjects = ["Algorithms", "Mathematics", "Physics", "Data Structures", "Chemistry", "English", "Operating Systems"];
  return rows.map((row, index) => {
    const date = new Date();
    date.setDate(date.getDate() - (21 - index));
    return {
      date: getDateString(date), bedtime: row[0], wakeTime: row[1], sleep: row[2],
      sleepQuality: row[3], studyHours: row[4], subject: subjects[index % subjects.length], focus: row[5]
    };
  });
}

function escapeHTML(text) {
  return String(text).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

let records;

try {
  const savedRecords = JSON.parse(localStorage.getItem("dreamlogRecords_v2"));
  records = Array.isArray(savedRecords) && savedRecords.length
    ? savedRecords
    : createDemoData();
} catch (error) {
  records = createDemoData();
}

function saveRecords() {
  localStorage.setItem("dreamlogRecords_v2", JSON.stringify(records));
}


// ==========================================
// HELPER FUNCTIONS
// ==========================================

function average(values) {
  if (!values.length) return 0;
  return values.reduce((sum, value) => sum + value, 0) / values.length;
}

function showToast(message) {
  const toast = document.getElementById("toast");
  toast.textContent = message;
  toast.classList.add("show");

  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => {
    toast.classList.remove("show");
  }, 2600);
}

function getSleepDuration(bedtime, wakeTime) {
  const [bedHour, bedMinute] = bedtime.split(":").map(Number);
  const [wakeHour, wakeMinute] = wakeTime.split(":").map(Number);

  let bed = bedHour * 60 + bedMinute;
  let wake = wakeHour * 60 + wakeMinute;

  if (wake <= bed) {
    wake += 24 * 60;
  }

  return Number(((wake - bed) / 60).toFixed(2));
}

function getTodayRecord() {
  const today = getDateString(new Date());

  let record = records.find(item => item.date === today);

  if (!record) {
    record = {
      date: today,
      bedtime: "",
      wakeTime: "",
      sleep: 0,
      sleepQuality: 0,
      studyHours: 0,
      subject: "Not recorded",
      focus: 0
    };

    records.push(record);
  }

  return record;
}


// ==========================================
// RATING BUTTONS
// ==========================================

let sleepRatingValue = 4;
let focusRatingValue = 5;

function setupRating(containerId, callback, initialValue) {
  const container = document.getElementById(containerId);
  const buttons = container.querySelectorAll("button");

  buttons.forEach(button => {
    button.addEventListener("click", function () {
      const value = Number(this.dataset.value);

      buttons.forEach(item => {
        item.classList.toggle(
          "selected",
          Number(item.dataset.value) <= value
        );
      });

      callback(value);
    });

    button.classList.toggle(
      "selected",
      Number(button.dataset.value) <= initialValue
    );
  });
}

setupRating("sleepRating", value => {
  sleepRatingValue = value;
}, sleepRatingValue);

setupRating("focusRating", value => {
  focusRatingValue = value;
}, focusRatingValue);


// ==========================================
// SLEEP DURATION PREVIEW
// ==========================================

const bedtimeInput = document.getElementById("bedtime");
const wakeInput = document.getElementById("wakeTime");

function updateDurationPreview() {
  if (!bedtimeInput.value || !wakeInput.value) return;

  const duration = getSleepDuration(
    bedtimeInput.value,
    wakeInput.value
  );

  document.getElementById("durationPreview").textContent =
    duration.toFixed(1) + " hours";
}

bedtimeInput.addEventListener("change", updateDurationPreview);
wakeInput.addEventListener("change", updateDurationPreview);

updateDurationPreview();


// ==========================================
// SAVE SLEEP LOG
// ==========================================

document.getElementById("sleepForm").addEventListener("submit", function (event) {
  event.preventDefault();

  const bedtime = bedtimeInput.value;
  const wakeTime = wakeInput.value;

  const duration = getSleepDuration(bedtime, wakeTime);

  if (duration <= 0 || duration > 24) {
    showToast("Please enter valid sleep timings.");
    return;
  }

  const record = getTodayRecord();

  record.bedtime = bedtime;
  record.wakeTime = wakeTime;
  record.sleep = duration;
  record.sleepQuality = sleepRatingValue;

  saveRecords();
  renderDashboard();

  showToast("Your sleep log has been saved!");
});


// ==========================================
// SAVE STUDY SESSION
// ==========================================

document.getElementById("studyForm").addEventListener("submit", function (event) {
  event.preventDefault();

  const subject = document.getElementById("subject").value.trim();
  const hours = Number(document.getElementById("studyHours").value);

  if (!subject || !Number.isFinite(hours) || hours <= 0 || hours > 8) {
    showToast("Enter a subject and study time up to 8 hours.");
    return;
  }

  const record = getTodayRecord();

  record.subject = subject;
  record.studyHours = Number(
    (Number(record.studyHours || 0) + hours).toFixed(2)
  );
  record.focus = focusRatingValue;

  saveRecords();
  renderDashboard();

  this.reset();
  showToast("Study session saved successfully!");
});


// ==========================================
// PEARSON CORRELATION
// ==========================================

function pearsonCorrelation(data) {
  if (data.length < 2) return null;

  const xValues = data.map(item => item.sleep);
  const yValues = data.map(item => item.focus);

  const xMean = average(xValues);
  const yMean = average(yValues);

  let numerator = 0;
  let xDenominator = 0;
  let yDenominator = 0;

  for (let i = 0; i < data.length; i++) {
    const xDifference = xValues[i] - xMean;
    const yDifference = yValues[i] - yMean;

    numerator += xDifference * yDifference;
    xDenominator += xDifference * xDifference;
    yDenominator += yDifference * yDifference;
  }

  const denominator = Math.sqrt(xDenominator * yDenominator);

  if (denominator === 0) return 0;

  return numerator / denominator;
}


// ==========================================
// LINEAR REGRESSION TRENDLINE
// ==========================================

function calculateTrendline(data) {
  if (data.length < 2) return [];

  const x = data.map(item => item.sleep);
  const y = data.map(item => item.focus);

  const xMean = average(x);
  const yMean = average(y);

  let numerator = 0;
  let denominator = 0;

  for (let i = 0; i < x.length; i++) {
    numerator += (x[i] - xMean) * (y[i] - yMean);
    denominator += (x[i] - xMean) ** 2;
  }

  if (denominator === 0) return [];

  const slope = numerator / denominator;
  const intercept = yMean - slope * xMean;

  const minX = Math.min(...x);
  const maxX = Math.max(...x);

  return [
    { x: minX, y: slope * minX + intercept },
    { x: maxX, y: slope * maxX + intercept }
  ];
}


// ==========================================
// CHART.JS SCATTER PLOT
// ==========================================

let sleepChart = null;

function renderChart() {
  const canvas = document.getElementById("sleepChart");
  if (!canvas || typeof Chart === "undefined") return;

  const validRecords = records.filter(item =>
    Number(item.sleep) > 0 &&
    Number(item.focus) > 0
  );

  const points = validRecords.map(item => ({
    x: Number(item.sleep),
    y: Number(item.focus)
  }));

  const trendline = calculateTrendline(validRecords);
  const newest = [...validRecords].sort((a, b) => a.date.localeCompare(b.date)).pop();
  const newestPoint = newest ? [{ x: Number(newest.sleep), y: Number(newest.focus) }] : [];

  if (sleepChart) {
    sleepChart.destroy();
  }

  sleepChart = new Chart(canvas, {
    type: "scatter",
    data: {
      datasets: [
        {
          label: "Sleep vs focus",
          data: points,
          backgroundColor: "#60a5fa",
          borderColor: "#93c5fd",
          pointRadius: 6,
          pointHoverRadius: 9
        },
        {
          type: "line",
          label: "Linear regression trendline",
          data: trendline,
          borderColor: "#6ee7b7",
          borderWidth: 2,
          borderDash: [6, 5],
          pointRadius: 0,
          showLine: true
        },
        {
          label: "Latest entry",
          data: newestPoint,
          backgroundColor: "#fbbf24",
          borderColor: "#ffffff",
          borderWidth: 2,
          pointRadius: 10,
          pointHoverRadius: 12
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      plugins: {
        legend: {
          display: false
        },
        tooltip: {
          backgroundColor: "#18233d",
          borderColor: "#60a5fa55",
          borderWidth: 1,
          padding: 12,
          callbacks: {
            label: function (context) {
              return ` ${context.parsed.x} hours sleep, ${context.parsed.y}/5 focus`;
            }
          }
        }
      },
      scales: {
        x: {
          type: "linear",
          min: 3,
          max: 11,
          title: {
            display: true,
            text: "Sleep duration (hours)",
            color: "#aeb8ce"
          },
          ticks: { color: "#8994ae" },
          grid: { color: "#ffffff0b" }
        },
        y: {
          min: 0,
          max: 5,
          title: {
            display: true,
            text: "Study focus rating",
            color: "#aeb8ce"
          },
          ticks: {
            stepSize: 1,
            color: "#8994ae"
          },
          grid: { color: "#ffffff0b" }
        }
      }
    }
  });
}


// ==========================================
// CORRELATION DISPLAY
// ==========================================

function renderCorrelation() {
  const validRecords = records.filter(item =>
    Number(item.sleep) > 0 &&
    Number(item.focus) > 0
  );

  const valueElement = document.getElementById("correlationValue");
  const labelElement = document.getElementById("correlationLabel");

  if (validRecords.length < 7) {
    valueElement.textContent = "—";
    labelElement.textContent = "Needs at least 7 days of logs for statistical confidence";
    labelElement.classList.add("badge-warn");
    return;
  }

  labelElement.classList.remove("badge-warn");
  const correlation = pearsonCorrelation(validRecords);

  valueElement.textContent =
    (correlation >= 0 ? "+" : "") + correlation.toFixed(2);

  if (correlation >= 0.7) {
    labelElement.textContent = "Strong positive correlation";
  } else if (correlation >= 0.3) {
    labelElement.textContent = "Moderate positive correlation";
  } else if (correlation <= -0.7) {
    labelElement.textContent = "Strong negative correlation";
  } else if (correlation <= -0.3) {
    labelElement.textContent = "Moderate negative correlation";
  } else {
    labelElement.textContent = "Weak or no correlation";
  }
}


// ==========================================
// DASHBOARD STATISTICS
// ==========================================

function renderStats() {
  const validSleep = records.filter(item => Number(item.sleep) > 0);
  const validStudy = records.filter(item => Number(item.studyHours) > 0);
  const validFocus = records.filter(item => Number(item.focus) > 0);

  const avgSleep = average(validSleep.map(item => Number(item.sleep)));
  const totalStudy = validStudy.reduce(
    (sum, item) => sum + Number(item.studyHours), 0
  );
  const avgFocus = average(validFocus.map(item => Number(item.focus)));

  const today = getDateString(new Date());
  const weekAgo = new Date();
  weekAgo.setDate(weekAgo.getDate() - 6);
  const startDate = getDateString(weekAgo);

  const weeklyRecords = validSleep.filter(item =>
    item.date >= startDate && item.date <= today
  );

  const sleepDebt = weeklyRecords.reduce((sum, item) => {
    return sum + Math.max(0, 8 - Number(item.sleep));
  }, 0);

  document.getElementById("avgSleep").innerHTML =
    `${avgSleep.toFixed(1)} <small>hrs</small>`;

  document.getElementById("totalStudy").innerHTML =
    `${totalStudy.toFixed(1)} <small>hrs</small>`;

  document.getElementById("avgFocus").innerHTML =
    `${avgFocus.toFixed(1)} <small>/ 5</small>`;

  document.getElementById("sleepDebt").innerHTML =
    `${sleepDebt.toFixed(1)} <small>hrs</small>`;

  document.getElementById("sleepProgress").style.width =
    Math.min(100, avgSleep / 8 * 100) + "%";

  document.getElementById("studyProgress").style.width =
    Math.min(100, totalStudy / 40 * 100) + "%";

  document.getElementById("focusProgress").style.width =
    Math.min(100, avgFocus / 5 * 100) + "%";

  document.getElementById("debtProgress").style.width =
    Math.min(100, sleepDebt / 20 * 100) + "%";
}


// ==========================================
// SMART INSIGHTS
// ==========================================

function renderInsights() {
  const container = document.getElementById("insightList");

  const valid = records.filter(item =>
    Number(item.sleep) > 0 && Number(item.focus) > 0
  );

  const avgSleep = average(valid.map(item => Number(item.sleep)));
  const avgFocus = average(valid.map(item => Number(item.focus)));
  const correlation = pearsonCorrelation(valid);

  let insights = [];

  if (valid.length >= 7) {
    const rested = valid.filter(item => Number(item.sleep) >= 7.5);
    const short = valid.filter(item => Number(item.sleep) < 7.5);
    if (rested.length >= 2 && short.length >= 2) {
      const restedFocus = average(rested.map(item => Number(item.focus)));
      const shortFocus = average(short.map(item => Number(item.focus)));
      const diff = Math.round((restedFocus - shortFocus) / shortFocus * 100);
      insights.push(
        `Days with 7.5+ hours of sleep averaged ${restedFocus.toFixed(1)}/5 focus versus ${shortFocus.toFixed(1)}/5 on shorter nights: ${Math.abs(diff)}% ${diff >= 0 ? "higher" : "lower"} focus (${rested.length} vs ${short.length} days).`
      );
    }
    const veryShort = valid.filter(item => Number(item.sleep) < 6);
    if (veryShort.length >= 2) {
      insights.push(
        `On ${veryShort.length} nights under 6 hours, your focus averaged ${average(veryShort.map(item => Number(item.focus))).toFixed(1)}/5. Sleep debt is costing you study quality.`
      );
    }
  }

  if (valid.length < 7) {
    insights.push(
      "Keep logging your sleep and study sessions. At least 7 complete days are recommended before interpreting your correlation."
    );
  } else {
    insights.push(
      `Your average sleep is ${avgSleep.toFixed(1)} hours. The recommended baseline in this project is 8 hours per night.`
    );

    if (correlation !== null && correlation > 0.3) {
      insights.push(
        `Your data shows a positive relationship between sleep duration and focus (r = ${correlation.toFixed(2)}).`
      );
    } else if (correlation !== null && correlation < -0.3) {
      insights.push(
        `Your data shows a negative relationship between sleep duration and focus (r = ${correlation.toFixed(2)}). Review your routine and continue tracking.`
      );
    } else {
      insights.push(
        "Your current data shows a weak relationship between sleep duration and focus. More consistent tracking may reveal a clearer pattern."
      );
    }
  }

  if (avgSleep < 7) {
    insights.push("Your average sleep is below 7 hours. Try creating a consistent bedtime routine.");
  } else if (avgSleep >= 8) {
    insights.push("Great work! Your average sleep meets or exceeds the 8-hour project baseline.");
  } else {
    insights.push("You are getting closer to the 8-hour sleep goal. Consider adding a little more rest.");
  }

  if (avgFocus >= 4) {
    insights.push(`Your average focus rating is ${avgFocus.toFixed(1)}/5. Keep building consistent study habits.`);
  } else {
    insights.push(`Your average focus rating is ${avgFocus.toFixed(1)}/5. Try shorter focused study sessions and regular breaks.`);
  }

  container.innerHTML = insights.map(text => `
    <div class="insight-item">
      <span class="insight-bullet">✧</span>
      <p>${escapeHTML(text)}</p>
    </div>
  `).join("");
}


// ==========================================
// HISTORY TABLE
// ==========================================

function renderHistory() {
  const tbody = document.getElementById("historyBody");

  const sorted = [...records].sort((a, b) =>
    b.date.localeCompare(a.date)
  );

  tbody.innerHTML = sorted.slice(0, 12).map(item => {
    const date = new Date(item.date + "T00:00:00");
    const displayDate = date.toLocaleDateString("en-IN", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    });

    const quality = Number(item.sleepQuality) > 0
      ? "★".repeat(Number(item.sleepQuality))
      : "—";

    return `
      <tr>
        <td>${displayDate}</td>
        <td>${Number(item.sleep || 0).toFixed(1)} hrs</td>
        <td class="star-text">${quality}</td>
        <td>${Number(item.studyHours || 0).toFixed(1)} hrs</td>
        <td>${escapeHTML(item.subject || "—")}</td>
        <td>${Number(item.focus || 0) > 0 ? item.focus + "/5" : "—"}</td>
      </tr>
    `;
  }).join("");
}


// ==========================================
// BEDTIME RECOMMENDER
// ==========================================

document.getElementById("recommendBtn").addEventListener("click", function () {
  const wakeTime = document.getElementById("recommendedWake").value;

  if (!wakeTime) {
    showToast("Please select your wake-up time.");
    return;
  }

  const [hour, minute] = wakeTime.split(":").map(Number);
  const wakeDate = new Date();
  wakeDate.setHours(hour, minute, 0, 0);

  const results = document.getElementById("bedtimeResults");

  const options = [6, 5, 4];

  results.innerHTML = options.map(cycles => {
    const bedtime = new Date(
      wakeDate.getTime() - (cycles * 90 + 15) * 60000
    );

    const time = bedtime.toLocaleTimeString("en-IN", {
      hour: "2-digit",
      minute: "2-digit",
      hour12: true
    });

    return `
      <div class="bedtime-option">
        <strong>${time}</strong>
        <span>${cycles} cycles · ${cycles * 1.5} hours sleep</span>
      </div>
    `;
  }).join("");
});


// ==========================================
// EXAM WEEK TIMETABLE
// ==========================================

document.getElementById("generatePlan").addEventListener("click", function () {
  const wakeTime = document.getElementById("examWake").value;
  const studyHours = Number(document.getElementById("examStudy").value);
  const subject = document.getElementById("examSubject").value.trim();

  if (!wakeTime || !subject || !Number.isFinite(studyHours) ||
      studyHours < 1 || studyHours > 8) {
    showToast("Enter valid details. Study time must be 1–8 hours.");
    return;
  }

  const [hour, minute] = wakeTime.split(":").map(Number);
  let currentMinutes = hour * 60 + minute;

  const sleepStart = (currentMinutes + 24 * 60 - 7 * 60) % (24 * 60);

  const tasks = [
    { label: "Morning routine & breakfast", duration: 60 },
    { label: `Study session 1 · ${subject}`, duration: Math.round(studyHours * 60 * 0.4) },
    { label: "Break & lunch", duration: 90 },
    { label: `Study session 2 · ${subject}`, duration: Math.round(studyHours * 60 * 0.35) },
    { label: "Rest, walk & refresh", duration: 60 },
    { label: `Revision session · ${subject}`, duration: studyHours * 60 - Math.round(studyHours * 60 * 0.75) },
    { label: "Dinner & free time", duration: 90 }
  ];

  function formatTime(minutes) {
    const normalized = ((minutes % 1440) + 1440) % 1440;
    const h = Math.floor(normalized / 60);
    const m = normalized % 60;
    const suffix = h >= 12 ? "PM" : "AM";
    const displayHour = h % 12 || 12;

    return `${displayHour}:${String(m).padStart(2, "0")} ${suffix}`;
  }

  let html = "";
  let totalStudy = 0;

  tasks.forEach(task => {
    const start = currentMinutes;
    const end = currentMinutes + task.duration;

    if (task.label.startsWith("Study") || task.label.startsWith("Revision")) {
      totalStudy += task.duration;
    }

    html += `
      <div class="schedule-row">
        <div class="schedule-time">${formatTime(start)} – ${formatTime(end)}</div>
        <div class="schedule-task">
          ${task.label}
          <small>${task.duration} minutes</small>
        </div>
      </div>
    `;

    currentMinutes = end;
  });

  html += `
    <div class="schedule-row">
      <div class="schedule-time">${formatTime(sleepStart)} – ${formatTime(sleepStart + 420)}</div>
      <div class="schedule-task">
        Protected sleep time
        <small>7 hours reserved for rest</small>
      </div>
    </div>
  `;

  document.getElementById("timetable").innerHTML = html;

  showToast(`Timetable generated. Study: ${(totalStudy / 60).toFixed(1)} hours.`);
});


// ==========================================
// EXPORT STUDENT WELLNESS REPORT
// ==========================================

document.getElementById("exportBtn").addEventListener("click", function () {
  const valid = records.filter(item =>
    Number(item.sleep) > 0 && Number(item.focus) > 0
  );

  const correlation = pearsonCorrelation(valid);
  const avgSleep = average(valid.map(item => Number(item.sleep)));
  const avgFocus = average(valid.map(item => Number(item.focus)));

  const reportWindow = window.open("", "_blank");

  if (!reportWindow) {
    showToast("Please allow pop-ups to export your report.");
    return;
  }

  const reportRows = [...records]
    .sort((a, b) => b.date.localeCompare(a.date))
    .map(item => `
      <tr>
        <td>${item.date}</td>
        <td>${Number(item.sleep || 0).toFixed(1)} hrs</td>
        <td>${Number(item.sleepQuality || 0)}/5</td>
        <td>${Number(item.studyHours || 0).toFixed(1)} hrs</td>
        <td>${escapeHTML(item.subject || "—")}</td>
        <td>${Number(item.focus || 0)}/5</td>
      </tr>
    `).join("");

  reportWindow.document.write(`
    <!DOCTYPE html>
    <html>
    <head>
      <title>DreamLog Student Wellness Report</title>
      <style>
        body { font-family: Arial, sans-serif; padding: 35px; color: #20243a; }
        h1 { color: #6d55c7; }
        p { color: #555; }
        .stats { display: flex; gap: 20px; margin: 25px 0; }
        .stat { border: 1px solid #ddd; padding: 15px; border-radius: 8px; flex: 1; }
        .stat strong { display: block; font-size: 23px; margin-top: 8px; }
        table { width: 100%; border-collapse: collapse; margin-top: 25px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; font-size: 12px; }
        th { background: #eeeafb; }
        button { padding: 10px 18px; background: #6d55c7; color: white; border: 0; border-radius: 6px; cursor: pointer; }
        @media print { button { display: none; } }
      </style>
    </head>
    <body>
      <h1>☾ DreamLog Student Wellness Report</h1>
      <p>Sleep and study productivity summary</p>
      <p>Generated on: ${new Date().toLocaleDateString("en-IN")}</p>

      <div class="stats">
        <div class="stat">Average sleep<strong>${avgSleep.toFixed(1)} hrs</strong></div>
        <div class="stat">Average focus<strong>${avgFocus.toFixed(1)}/5</strong></div>
        <div class="stat">Pearson r<strong>${correlation === null ? "—" : correlation.toFixed(2)}</strong></div>
      </div>

      <p>Note: Correlation indicates association, not causation. At least seven complete days are recommended for interpretation.</p>

      <h2>Activity history</h2>
      <table>
        <thead>
          <tr><th>Date</th><th>Sleep</th><th>Quality</th><th>Study</th><th>Subject</th><th>Focus</th></tr>
        </thead>
        <tbody>${reportRows}</tbody>
      </table>

      <br>
      <button onclick="window.print()">Print / Save as PDF</button>
    </body>
    </html>
  `);

  reportWindow.document.close();
});


// ==========================================
// RENDER EVERYTHING
// ==========================================

function renderDashboard() {
  renderStats();
  renderCorrelation();
  renderChart();
  renderInsights();
  renderHistory();
}


// ==========================================
// DATE DISPLAY & NAVIGATION
// ==========================================

document.getElementById("todayDate").textContent =
  new Date().toLocaleDateString("en-IN", {
    day: "2-digit",
    month: "short",
    year: "numeric"
  });

const navLinks = document.querySelectorAll(".nav-link");

navLinks.forEach(link => {
  link.addEventListener("click", function () {
    navLinks.forEach(item => item.classList.remove("active"));
    this.classList.add("active");
  });
});


// INITIALIZE DASHBOARD
renderDashboard();

// Dynamic greeting
(function () {
  const hour = new Date().getHours();
  const greeting = hour < 12 ? "Good Morning" : hour < 17 ? "Good Afternoon" : "Good Evening";
  const heading = document.querySelector(".topbar h1");
  if (heading) heading.firstChild.textContent = greeting + ", ";
})();

// Reset demo data
document.getElementById("resetData").addEventListener("click", function (event) {
  event.preventDefault();
  if (confirm("Reset to the 21-day demo dataset? Your logs will be cleared.")) {
    localStorage.removeItem("dreamlogRecords_v2");
    location.reload();
  }
});
