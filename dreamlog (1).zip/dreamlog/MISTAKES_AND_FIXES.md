# DreamLog: Analysis of Previous Attempt vs. Problem Brief

Reviewed: index.html, style.css, script.js against the 3-page SnoozeScience Sprint brief.
(No separate "analysis report" file was in the upload, only the brief, so this is based on the brief + your code.)

## Fatal / high-impact mistakes (FIXED in this zip)
| # | Mistake | Why it costs marks | Fix |
|---|---------|--------------------|-----|
| 1 | Login page displays `student@gmail.com` but script.js accepted only a personal email | Demo account fails; judges can't get in | Credentials now match the on-screen demo box (student@gmail.com / dreamlog123); personal email removed |
| 2 | Seed data gave r ≈ +0.97 | Brief's demo expects r ≈ +0.78 "Strong Positive" after logging 8.0 h / 5★ | New 21-day dataset: r = +0.77 before, **+0.78 after** the demo entry (verified in Node) |
| 3 | Seed bed/wake always 23:30→07:30 while sleep varied 5-8.5 h; study hours were a formula of focus | Data looked fake and self-contradictory | Bed/wake times now match each night's duration; study hours 2-7 with natural noise |
| 4 | "Weekly Optimization Insights" were generic tips | Brief's example: "7.5+ hours saw 34% higher focus" | Computed insight: avg focus on 7.5+ h nights vs shorter nights, with % difference and sample sizes; plus <6 h warning |
| 5 | New data point not highlighted on scatter | Brief: "scatter plot highlights the new data point" | Latest entry drawn as a large amber point |
| 6 | Purple/black palette | Brief tip: deep navy #0F172A with soft amber/blue accents | Theme recoloured: #0F172A background, blue + amber accents |
| 7 | Subject text inserted via innerHTML (XSS) | Robustness/security | `escapeHTML()` on all user text |
| 8 | Unpinned `chart.js` CDN, no fallback | Chart blank if CDN/Wi-Fi fails or version changes | Pinned 4.4.1 + local `vendor/` fallback |
| 9 | 7-day warning looked like a normal badge | Brief asks for a clear helper badge | Amber badge: "Needs at least 7 days of logs for statistical confidence" |
| 10 | Hard-coded "Good Afternoon"; stale localStorage kept old seed | Polish; users stuck with old data | Time-based greeting; new storage key + "Reset demo data" link in footer |
| 11 | Study form blank at demo time | Demo script needs 4.5 h Algorithms | Pre-filled with Algorithms / 4.5 h (sleep form already 23:30→07:30, 4★) |

## Still missing, worth adding if you have time (not done in this zip)
- **Caffeine Intake Logger** with half-life overlay vs bedtime (stretch).
- **Chart of sleep debt vs. study efficiency** (objective mentions visualizing it; debt is currently a number + bar).
- Optional exam-score field so the exported report can correlate sleep with exam performance.
- Backend/TypeScript/React stack is only *suggested*; localStorage is explicitly allowed by the brief.

## Rules for the next attempt (to reach ~95%)
1. Make the brief's demo script work first, character for character, before adding anything.
2. Test the login on a fresh browser profile and phone before submitting.
3. Verify the number the brief quotes (r = +0.78) from the real code.
4. Never ship hard-coded personal data; keep credentials identical in UI and code.
5. Pin CDN versions; keep an offline fallback.
6. Cover every Must-Have bullet visibly, then stretch features in order.
